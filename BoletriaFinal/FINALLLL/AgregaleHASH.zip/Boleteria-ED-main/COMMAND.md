```bash
  
g++ -Imodel -Iview -Iutils -Icontroller -o beta6 controller/main.cpp model/ListaCircularDoble.cpp utils/Validaciones.cpp view/MenuUI.cpp view/MenuController.cpp view/StringProcessor.cpp controller/EventManager.cpp controller/ReservationManager.cpp controller/Exhaustiva.cpp controller/DivideYVenceras.cpp controller/Voraz.cpp controller/Dinamica.cpp controller/Backtracking.cpp

```